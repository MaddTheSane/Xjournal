/*
 *  (C) Copyright 2000 Mulle kybernetiK. All rights reserved. 
 * 
 *  Permission to use, copy, modify and distribute this software and its
 *  documentation is hereby granted, provided that both the copyright
 *  notice and this permission notice appear in all copies of the
 *  software, derivative works or modified versions, and any portions
 *  thereof, and that both notices appear in supporting documentation, 
 *  and that credit is given to Mulle kybernetiK in all documents and
 *  publicity pertaining to direct or indirect use of this code or its
 *  derivatives. 
 * 
 *  THIS IS EXPERIMENTAL SOFTWARE AND IT IS KNOWN TO HAVE BUGS, SOME OF
 *  WHICH MAY HAVE SERIOUS CONSEQUENCES. THE COPYRIGHT HOLDER ALLOWS FREE
 *  USE OF THIS SOFTWARE IN ITS "AS IS" CONDITION. THE COPYRIGHT HOLDER
 *  DISCLAIMS ANY LIABILITY OF ANY KIND FOR ANY DAMAGES WHATSOEVER
 *  RESULTING DIRECTLY OR INDIRECTLY FROM THE USE OF THIS SOFTWARE OR OF
 *  ANY DERIVATIVE WORK.
 *
 *  Coded by Nat!
 *
 *  $Id: MulleSymmetricCipherKey.m,v 1.1.1.1 2001/02/22 14:55:31 znek Exp $
 *
 *  $Log: MulleSymmetricCipherKey.m,v $
 *  Revision 1.1.1.1  2001/02/22 14:55:31  znek
 *  Re-import of Nat!'s cryptographic framework. This version has been
 *  ported to MOSX, MOSXS and Solaris. It uses an extended build process
 *  similar to EDCommon & friends.
 *
 *  Revision 1.1.1.1  1970/01/01 22:37:33  nat
 *  Mercyful Release
 *
 */

#import "MulleSymmetricCipherKey.h"
#import "MulleCipherCryptoException.h"
#import "MulleCipherCryptoPrivate.h"


@implementation MulleSymmetricCipherKey 

#warning (nat) oughta code the initWithCoder... stuff


// some things we do not want you to do....

static void  pain( id self, SEL _cmd)
{
   [NSException raise:NSGenericException
               format:@"Do not call %@ %@", self, NSStringFromSelector( _cmd)];
}


static void  pain2( id self, SEL _cmd)
{
   [NSException raise:NSGenericException
               format:@"The subclass %@ needs to implement %@", self, NSStringFromSelector( _cmd)];
}

+ (id) alloc
{
   pain( self, _cmd);
   return( nil);
}


- (id) init
{
   pain( self, _cmd);
   return( nil);
}


+ (id) allocWithZone:(NSZone *) zone
{
   pain( self, _cmd);
   return( nil);
}


void   MulleSymmetricCipherKeyAssertType( Class self, int type)
{
   if( type != MulleCipherForEncryption &&
       type != MulleCipherForDecryption)
      [NSException raise:MulleCipherCryptoException
                  format:@"The direction for %@ must either be MulleCipherForEncryption or MulleCipherForDecryption", self];
}


void   MulleSymmetricCipherKeyAssertKeyLength( Class self, unsigned int n)
{
   if( n < [self minKeyLength] || n > [self maxKeyLength])
      [NSException raise:MulleCipherCryptoException
                  format:@"Silly key data with %u bytes. Data must be between %u and %u bytes",
         n, [self minKeyLength], [self maxKeyLength]];
}


+ (id) keyWithData:(NSData *) data
      forDirection:(MulleSymmetricCipherKeyType) type
{
   unsigned int              size;
   MulleSymmetricCipherKey   *obj;

#if DEBUG
   NSAssert( [data isKindOfClass:[NSData class]], @"loss1");
#endif   
   size = [data length];

#if DEBUG   
//   MulleSymmetricCipherKeyAssertType( self, type);   // must be done in subclass!!
   MulleSymmetricCipherKeyAssertKeyLength( self, size);
#endif
   obj          = NSAllocateObject( self, size, NULL);
   obj->length  = size;
   obj->keyType = type;
   memcpy( obj + 1, [data bytes], size);
   
   return( [obj autorelease]);
}


- (void) dealloc
{
   [self destroy];	// already paranoid ?
   [super dealloc];
}


- (BOOL) isForEncryption
{
   return( keyType != MulleCipherForDecryption);
}


- (BOOL) isForDecryption
{
   return( keyType != MulleCipherForEncryption);
}



// users should not call this. it is a) paranoid and
// b) implies that users key handling is sloppy anyway!
- (BOOL) isDestroyed
{
   return( isDestroyed);
}


- (const void *) bytes
{
#if DEBUG   
   if( [self isDestroyed])
      [NSException raise:MulleCipherCryptoException
                  format:@"Key %@ has been destroyed already", self];
#endif   
   return( self + 1);
}



- (unsigned int) length
{
   return( length);
}


- (NSData *) data
{
   return( [NSData dataWithBytes:[self bytes]
                          length:[self length]]);
}


- (void) destroy
{
   memset( self + 1, 0, [self length]);
   isDestroyed = YES;
}


+ (unsigned int) minKeyLength
{
   return( 32 / 8);
}


+ (unsigned int) maxKeyLength
{
   pain2( self, _cmd);
   return( 0);
}

@end
