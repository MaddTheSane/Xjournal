/*
 *  (C) Copyright 2000,2002 Mulle kybernetiK. All rights reserved. 
 * 
 *  Permission to use, copy, modify and distribute this software and its
 *  documentation is hereby granted, provided that both the copyright
 *  notice and this permission notice appear in all copies of the
 *  software, derivative works or modified versions, and any portions
 *  thereof, and that both notices appear in supporting documentation, 
 *  and that credit is given to Mulle kybernetiK in all documents and
 *  publicity pertaining to direct or indirect use of this code or its
 *  derivatives. 
 * 
 *  THIS IS EXPERIMENTAL SOFTWARE AND IT IS KNOWN TO HAVE BUGS, SOME OF
 *  WHICH MAY HAVE SERIOUS CONSEQUENCES. THE COPYRIGHT HOLDER ALLOWS FREE
 *  USE OF THIS SOFTWARE IN ITS "AS IS" CONDITION. THE COPYRIGHT HOLDER
 *  DISCLAIMS ANY LIABILITY OF ANY KIND FOR ANY DAMAGES WHATSOEVER
 *  RESULTING DIRECTLY OR INDIRECTLY FROM THE USE OF THIS SOFTWARE OR OF
 *  ANY DERIVATIVE WORK.
 *
 *  Coded by Nat!
 *
 *  $Id: MulleSymmetricCipher.m,v 1.1.1.1 2001/02/22 14:55:31 znek Exp $
 *
 *  $Log: MulleSymmetricCipher.m,v $
 *  Revision 1.1.1.1  2001/02/22 14:55:31  znek
 *  Re-import of Nat!'s cryptographic framework. This version has been
 *  ported to MOSX, MOSXS and Solaris. It uses an extended build process
 *  similar to EDCommon & friends.
 *
 *  Revision 1.1.1.1  1970/01/01 22:37:32  nat
 *  Mercyful Release
 *
 */

#import "MulleSymmetricCipher.h"
#import "MulleSymmetricCipherKey.h"


@implementation MulleSymmetricCipher


static NSMutableDictionary  *ciphers;


static inline NSMutableDictionary  *ciphersDictionary()
{
   if( ! ciphers)
      ciphers = [[NSMutableDictionary alloc] init];
   return( ciphers);
}


//
// them bookkeeping methods
//
+ (void) registerCipher:(MulleSymmetricCipher *) cipher
{
   if( ! [cipher isKindOfClass:self])
   {
      fprintf( stderr, "you're trying hard to hose the system, but failing...\n");
      return;
   }
   [ciphersDictionary() setObject:cipher
                           forKey:[cipher name]];
}


+ (void) unregisterCipher:(MulleSymmetricCipher *) cipher
{
   if( ! [cipher isKindOfClass:self])
   {
      fprintf( stderr, "you're trying hard to hose the system, but failing...\n");
      return;
   }

   [ciphersDictionary() removeObjectForKey:[cipher name]];
}

//
// Might look thru plug-in directory, some time in the future...
//
+ (id) cipherWithName:(NSString *) name
{
   return( [ciphersDictionary() objectForKey:name]);
}   

//
// though, its nowhere written in the documentation, it has always
// been that allValues indices correspond to allKeys indices
// lets be bold and rely on this one more time
//
+ (NSArray *) registeredCiphers
{
   return( [ciphersDictionary() allValues]);
}


+ (NSArray *) registeredCipherNames
{
   return( [ciphersDictionary() allKeys]);
}


//
// Some helpful methods and functions for
//
static void  pain( id self, SEL _cmd)
{
   [NSException raise:NSGenericException
               format:@"You need to implement %@ in subclass %@", NSStringFromSelector( _cmd),
      [self class]];
}

/*#
###
###   Facilities to encode/decode the footer
### 
#*/
static char   magic[] = MulleCipherPaddingFooterMagic;

static MulleCipherPaddingFooter   *paddingFooter( unsigned char *p, unsigned int len)
{
   MulleCipherPaddingFooter   *footer;

   if( len < sizeof( MulleCipherPaddingFooter))
      return( 0);
   if( memcmp( &p[ len - sizeof( magic)], magic, sizeof( magic)))
      return( 0);
   footer = (MulleCipherPaddingFooter *)  &p[ len - sizeof( MulleCipherPaddingFooter)];
   if( footer->versionMajor != MulleCipherPaddingFooterMajorVersion)
      return( 0); // can't deal with it
   return( footer);
}


- (BOOL) hasFooterAppended:(NSData *) data
{
   return( ! ! paddingFooter( (void *) [data bytes], [data length]));
}


//
// These routines adjust for the blocking nature of the
// blowfish and twofish algorithms. Some extra bytes are
// added and removed to the ciphertext so that the original
// length of the encrypted data can be restored. This
// is a MulleCipher specific feature and therefore it's
// output nonportable (to a degree). The resulting plaintext
// on a non-Mulle decoder will get a bit of garbage at the
// end
void   MulleSymmetricCipherAppendSizeInfo( NSMutableData *data,
                                           unsigned int originalLen,
                                           unsigned int blockSize)
{
   unsigned int              len;
   unsigned int              tail;
   MulleCipherPaddingFooter  *footer;

   tail = blockSize - (originalLen & (blockSize - 1));
   if( tail == blockSize)
      tail = 0;

   //
   // increase storage for footer
   //
   len = [data length];
   [data increaseLengthBy:sizeof( MulleCipherPaddingFooter)];
   footer = (MulleCipherPaddingFooter *) &(((unsigned char *) [data mutableBytes])[ len]);

   tail += sizeof( MulleCipherPaddingFooter);
   footer->lenMSB = tail >> 8;
   footer->lenLSB = tail & 0xFF;
   footer->versionMajor = MulleCipherPaddingFooterMajorVersion;
   footer->versionMinor = MulleCipherPaddingFooterMinorVersion;
   memcpy( footer->magic, magic, sizeof( magic));
}


unsigned int   MulleSymmetricCipherRemoveSizeInfo( NSMutableData *data)
{
   MulleCipherPaddingFooter  *footer;
   unsigned char             *p;
   unsigned int              len;
   unsigned int              originalLen;

   p   = (unsigned char *) [data bytes];
   len = [data length];

   if( ! (footer = paddingFooter( p, len)))
      return( len);

   originalLen = len - ((footer->lenMSB << 8) | footer->lenLSB);
   [data setLength:len - sizeof( MulleCipherPaddingFooter)];

   return( originalLen);
}


- (void) appendSizeInfoToPlaintext:(NSMutableData *) data
                   plaintextLength:(unsigned int) length
{
   MulleSymmetricCipherAppendSizeInfo( data, length, [self blockingFactor]);
}


- (unsigned int )  removeSizeInfoFromPlaintext:(NSMutableData *) data
{
   return( MulleSymmetricCipherRemoveSizeInfo( data));
}


/*#
### **********************************************************
### that's the interface you HAVE to override in your subclass
### 
##*/
- (NSString *) name
{
   pain( self, _cmd);
   return( nil);
}


//
// your MulleSymmetricCipherKey subclass
//
- (Class) keyClass
{
   pain( self, _cmd);
   return( nil);
}


- (NSData *) decryptedData:(NSData *) data
                   withKey:(MulleSymmetricCipherKey *) key
         withInitialValues:(NSData *) values
{
   pain( self, _cmd);
   return( nil);
}


- (NSData *) encryptedData:(NSData *) data
                   withKey:(MulleSymmetricCipherKey *) key
         withInitialValues:(NSData *) values
{
   pain( self, _cmd);
   return( nil);
}

/*#
### **********************************************************
##*/




/*#
### You need to override these default values
### if they don't match your cipher algorithm
##*/
- (unsigned int) sizeOfInitialValues
{
   return( 0);
}


- (BOOL) mutableDataMethodsAreFast
{
   return( NO);
}


- (BOOL) immutableDataMethodsAreFast
{
   return( YES);
}


//
// a blocking factor of 1 means that no length Encoding is needed
// see above
//
- (unsigned int) blockingFactor
{
   return( 1);
}


/*#
###
### Some generic funtionality for encoding size, based on "blockingFactor"
### 
#*/
- (void) encryptDataWithFooter:(NSMutableData *) data
                       withKey:(MulleSymmetricCipherKey *) key
             withInitialValues:(NSData *) values
{
   unsigned int  originalLen;

#if DEBUG
   NSAssert( [data isKindOfClass:[NSMutableData class]], @"loss1");
   NSAssert( [key isKindOfClass:[MulleSymmetricCipherKey class]], @"loss2");
   NSAssert( ! values || [values isKindOfClass:[NSData class]], @"loss3");
#endif
   originalLen = [data length];
   [self encryptData:data
             withKey:key
   withInitialValues:values];
   [self appendSizeInfoToPlaintext:data
                   plaintextLength:originalLen];
}


- (void) decryptDataWithFooter:(NSMutableData *) data
                       withKey:(MulleSymmetricCipherKey *) key
             withInitialValues:(NSData *) values
{
   unsigned int  originalLength;
   
#if DEBUG
   NSAssert( [data isKindOfClass:[NSMutableData class]], @"loss1");
   NSAssert( [key isKindOfClass:[MulleSymmetricCipherKey class]], @"loss2");
   NSAssert( ! values || [values isKindOfClass:[NSData class]], @"loss3");
#endif
   originalLength = [self removeSizeInfoFromPlaintext:data];
   [self decryptData:data
             withKey:key
   withInitialValues:values];
   [data setLength:originalLength];
}



/*#
###
### All of the following code is generic, and need not be
### overriden or even understood by a subclass implementor.
### Though it isn't forbidden to judiciously override :)
###
#*/

//
// we have defined that non mutable conversion is the default, so
// make some slow default conversions, if inplace conversion isn't
// available from the subclass, that would override these two
// methods.
// 
- (void) encryptData:(NSMutableData *) data
             withKey:(MulleSymmetricCipherKey *) key
   withInitialValues:(NSData *) values
{
   NSData        *code;
   int           diff;
   unsigned int  len;

#if DEBUG
   NSAssert( [data isKindOfClass:[NSMutableData class]], @"loss1");
   NSAssert( [key isKindOfClass:[MulleSymmetricCipherKey class]], @"loss2");
   NSAssert( ! values || [values isKindOfClass:[NSData class]], @"loss3");
#endif
   code = [self encryptedData:data
                      withKey:key
            withInitialValues:values];
   len  = [code length];
   diff = (long) len - (long) [data length];
   if( diff > 0)
      [data increaseLengthBy:diff];

   // a simple memcpy is probably better...
   [data replaceBytesInRange:NSMakeRange( 0, len)
                   withBytes:[code bytes]];
}


- (void) decryptData:(NSMutableData *) data
             withKey:(MulleSymmetricCipherKey *) key
   withInitialValues:(NSData *) values
{
   NSData        *plain;
   int           diff;
   unsigned int  len;

#if DEBUG
   NSAssert( [data isKindOfClass:[NSMutableData class]], @"loss1");
   NSAssert( [key isKindOfClass:[MulleSymmetricCipherKey class]], @"loss2");
   NSAssert( ! values || [values isKindOfClass:[NSData class]], @"loss3");
#endif
   plain = [self decryptedData:data
                       withKey:key
             withInitialValues:values];
   len  = [plain length];
   diff = (long) len - (long) [data length];
   if( diff > 0)
      [data increaseLengthBy:diff];

   // a simple memcpy is probably better...
   [data replaceBytesInRange:NSMakeRange( 0, len)
                   withBytes:[plain bytes]];
}


- (NSData *) encryptedDataWithFooter:(NSData *) data
                             withKey:(MulleSymmetricCipherKey *) key
                   withInitialValues:(NSData *) values
{
   NSMutableData  *copy;

   copy = [[data mutableCopy] autorelease];
   [self encryptDataWithFooter:copy
                       withKey:key
             withInitialValues:values];
   return( copy);
}



- (NSData *) decryptedDataWithFooter:(NSData *) data
                             withKey:(MulleSymmetricCipherKey *) key
                   withInitialValues:(NSData *) values
{
   NSMutableData  *copy;

   copy = [[data mutableCopy] autorelease];
   [self decryptDataWithFooter:copy
                       withKey:key
             withInitialValues:values];
   return( copy);
}



//
//   	ULTRA CONVENIENT INTERFACE
//
//
NSString  *MulleCipherPlaintextLength = @"MulleCipherPlaintextLength";
NSString  *MulleCipherCiphertext      = @"MulleCipherCiphertext";
//NSString  *MulleCipherChecksum      = @"MulleCipherChecksum";
//NSString  *MulleCipherEncoding        = @"MulleCipherEncoding";	// hyper convenient...

- (NSDictionary *) crypt:(NSData *) plaintext
                password:(NSData *) password
{
   MulleSymmetricCipherKey  *key;

   key = [[self keyClass] keyWithData:password
                         forDirection:MulleCipherForEncryption];
   return( [NSDictionary dictionaryWithObjectsAndKeys:
      [self encryptedData:plaintext
                  withKey:key], MulleCipherCiphertext,
      [NSNumber numberWithInt:[plaintext length]], MulleCipherPlaintextLength,
         nil]);
}


- (NSData *) decrypt:(NSDictionary *) dictionary
            password:(NSData *) password
{
   NSData         *ciphertext;
   NSNumber       *length;
   NSData         *data;
   MulleSymmetricCipherKey  *key;
   unsigned int   n;

   length     = [dictionary objectForKey:MulleCipherPlaintextLength];
   ciphertext = [dictionary objectForKey:MulleCipherCiphertext];

   NSAssert( length && ciphertext, @"dictionary incomplete");

   key = [[self keyClass] keyWithData:password
                         forDirection:MulleCipherForDecryption];

   data = [self decryptedData:ciphertext
                      withKey:key];
   n = [length intValue];
   if( n < [data length])
   {
      if( ! [data isKindOfClass:[NSMutableData class]])
         data = [[data mutableCopy] autorelease];
      [(NSMutableData *) data setLength:n];
   }
   return( data);
}



//
// 		CONVENIENCE INTERFACE
//
// It's usually unnecessary to override these
//
- (void) encryptData:(NSMutableData *) data
             withKey:(MulleSymmetricCipherKey *) key
{
   unsigned int  n;
   NSData        *values;

#if DEBUG
   NSAssert( [data isKindOfClass:[NSData class]], @"loss1");
   NSAssert( [key isKindOfClass:[MulleSymmetricCipherKey class]], @"loss2");
#endif
   values = nil;
   if( n = [self sizeOfInitialValues])
      values = [NSMutableData dataWithLength:n];
   
   [self encryptData:data
             withKey:key
   withInitialValues:values];
}


- (void) decryptData:(NSMutableData *) data
             withKey:(MulleSymmetricCipherKey *) key
{
   unsigned int  n;
   NSData        *values;

#if DEBUG
   NSAssert( [data isKindOfClass:[NSData class]], @"loss1");
   NSAssert( [key isKindOfClass:[MulleSymmetricCipherKey class]], @"loss2");
#endif
   values = nil;
   if( n = [self sizeOfInitialValues])
      values = [NSMutableData dataWithLength:n];
   
   [self decryptData:data
             withKey:key
   withInitialValues:values];
}



//
// FOLLOWING UP JUST THE SAME AS ABOVE BUT INPLACE METHODS
//
- (NSData *) encryptedData:(NSData *) data
                   withKey:(MulleSymmetricCipherKey *) key
{
   unsigned int  n;
   NSData        *values;

#if DEBUG
   NSAssert( [data isKindOfClass:[NSData class]], @"loss1");
   NSAssert( [key isKindOfClass:[MulleSymmetricCipherKey class]], @"loss2");
#endif
   values = nil;
   if( n = [self sizeOfInitialValues])
      values = [NSMutableData dataWithLength:n];
   
   return( [self encryptedData:data
                       withKey:key
             withInitialValues:values]);
}


- (NSData *) decryptedData:(NSData *) data
                   withKey:(MulleSymmetricCipherKey *) key;

{
   unsigned int  n;
   NSData        *values;

#if DEBUG
   NSAssert( [data isKindOfClass:[NSData class]], @"loss1");
   NSAssert( [key isKindOfClass:[MulleSymmetricCipherKey class]], @"loss2");
#endif
   values = nil;
   if( n = [self sizeOfInitialValues])
      values = [NSMutableData dataWithLength:n];
   
   return( [self decryptedData:data
                       withKey:key
             withInitialValues:values]);
}




//
// OK NOW JUST THE SAME AS ABOVE BUT ENCODE SIZE INTO PLAINTEXT
//
- (void) encryptDataWithFooter:(NSMutableData *) data
                       withKey:(MulleSymmetricCipherKey *) key
{
   unsigned int  n;
   NSData        *values;

#if DEBUG
   NSAssert( [data isKindOfClass:[NSData class]], @"loss1");
   NSAssert( [key isKindOfClass:[MulleSymmetricCipherKey class]], @"loss2");
#endif
   values = nil;
   if( n = [self sizeOfInitialValues])
      values = [NSMutableData dataWithLength:n];

   [self encryptDataWithFooter:data
                       withKey:key
             withInitialValues:values];
}



- (void) decryptDataWithFooter:(NSMutableData *) data
                       withKey:(MulleSymmetricCipherKey *) key
{
   unsigned int  n;
   NSData        *values;

#if DEBUG
   NSAssert( [data isKindOfClass:[NSData class]], @"loss1");
   NSAssert( [key isKindOfClass:[MulleSymmetricCipherKey class]], @"loss2");
#endif
   values = nil;
   if( n = [self sizeOfInitialValues])
      values = [NSMutableData dataWithLength:n];
   
   [self decryptDataWithFooter:data
                       withKey:key
             withInitialValues:values];
}


- (NSData *) encryptedDataWithFooter:(NSData *) data
                             withKey:(MulleSymmetricCipherKey *) key
{
   unsigned int  n;
   NSData        *values;

#if DEBUG
   NSAssert( [data isKindOfClass:[NSData class]], @"loss1");
   NSAssert( [key isKindOfClass:[MulleSymmetricCipherKey class]], @"loss2");
#endif
   values = nil;
   if( n = [self sizeOfInitialValues])
      values = [NSMutableData dataWithLength:n];
   
   return( [self encryptedDataWithFooter:data
                                 withKey:key
                       withInitialValues:values]);
}


- (NSData *) decryptedDataWithFooter:(NSData *) data
                             withKey:(MulleSymmetricCipherKey *) key;

{
   unsigned int  n;
   NSData        *values;

#if DEBUG
   NSAssert( [data isKindOfClass:[NSData class]], @"loss1");
   NSAssert( [key isKindOfClass:[MulleSymmetricCipherKey class]], @"loss2");
#endif
   values = nil;
   if( n = [self sizeOfInitialValues])
      values = [NSMutableData dataWithLength:n];
   
   return( [self decryptedDataWithFooter:data
                                 withKey:key
                       withInitialValues:values]);
}


@end
