/*
 *  (C) Copyright 2000 Mulle kybernetiK. All rights reserved. 
 * 
 *  Permission to use, copy, modify and distribute this software and its
 *  documentation is hereby granted, provided that both the copyright
 *  notice and this permission notice appear in all copies of the
 *  software, derivative works or modified versions, and any portions
 *  thereof, and that both notices appear in supporting documentation, 
 *  and that credit is given to Mulle kybernetiK in all documents and
 *  publicity pertaining to direct or indirect use of this code or its
 *  derivatives. 
 * 
 *  THIS IS EXPERIMENTAL SOFTWARE AND IT IS KNOWN TO HAVE BUGS, SOME OF
 *  WHICH MAY HAVE SERIOUS CONSEQUENCES. THE COPYRIGHT HOLDER ALLOWS FREE
 *  USE OF THIS SOFTWARE IN ITS "AS IS" CONDITION. THE COPYRIGHT HOLDER
 *  DISCLAIMS ANY LIABILITY OF ANY KIND FOR ANY DAMAGES WHATSOEVER
 *  RESULTING DIRECTLY OR INDIRECTLY FROM THE USE OF THIS SOFTWARE OR OF
 *  ANY DERIVATIVE WORK.
 *
 *  Coded by Nat!
 *
 *  $Id: MulleCipherBase.h,v 1.1.1.1 2001/02/22 14:55:31 znek Exp $
 *
 *  $Log: MulleCipherBase.h,v $
 *  Revision 1.1.1.1  2001/02/22 14:55:31  znek
 *  Re-import of Nat!'s cryptographic framework. This version has been
 *  ported to MOSX, MOSXS and Solaris. It uses an extended build process
 *  similar to EDCommon & friends.
 *
 *  Revision 1.1.1.1  1970/01/01 22:37:33  nat
 *  Mercyful Release
 *
 */

#import <Foundation/Foundation.h>

//
// the paranoid setting could/should do the following
// wire pages into memory, so that they are not swapped
// out to disk. Secondly clear memory of plaintext as
// soon as it isn't needed. At the moment this setting
// does nothing...
//
#define MULLE_CIPHER_PARANOID   0
#define MULLE_CIPHER_VOLATILE   // either <nothing> or volatile

@interface MulleCipherBase : NSObject
{
  // just a as of now bogus superclass. public key anybody ???
}


//
// for fastest randomization use the MersenneTwister directly
//
void  MulleCipherRandomizeBlockContents( void *buf, unsigned int len);
void  MulleCipherRandomizeSmallBlockContents( void *buf, unsigned int len);
void  MulleCipherRandomizeLargeBlockContents( void *buf, unsigned int len);

@end
