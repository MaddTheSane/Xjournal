/*
 * (C) Copyright 2000 Mulle kybernetiK
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND MULLE KYBERNETIK DISCLAIMS
 * ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL MULLE KYBERNETIK
 * BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL
 * DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
 * PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS
 * ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
 * SOFTWARE.
 *
 * $Id: NSData+MulleCipherCrpyto.m,v 1.1.1.1 2001/02/22 14:55:31 znek Exp $
 *
 * $Log: NSData+MulleCipherCrpyto.m,v $
 * Revision 1.1.1.1  2001/02/22 14:55:31  znek
 * Re-import of Nat!'s cryptographic framework. This version has been
 * ported to MOSX, MOSXS and Solaris. It uses an extended build process
 * similar to EDCommon & friends.
 *
 * Revision 1.1.1.1  1970/01/01 22:37:32  nat
 * Mercyful Release
 *
 *
 */
#import "NSData+MulleCipherCrpyto.h"
#import "NSMutableData+MulleCipherCrpyto.h"
#import "MulleCipherTwofishKey.h"
#import "MulleCipherCryptoException.h"
#include "aes.h"


typedef enum
{
   MulleCipherTwofishECB  = 1,
   MulleCipherTwofishCBC  = 2,
   MulleCipherTwofishCFB1 = 3
} MulleCipherTwofishMode;


@implementation NSData ( MulleCipherCrpyto)

#if 0 && THATS_HOW_IT_LOOKED_THE_FIRST_TIME_AROUND
//
// doing this with a mutableCopy means that we have
// one extraneous memory access per word
//
- (NSData *) blowfishEncryptedDataWithKeyData:(NSData *) key
{
   NSMutableData   *data;

   data = [self mutableCopy];
   [data blowfishEncryptWithKey:key];
   return( [data autorelease]);
}


- (NSData *) blowfishDecryptedDataWithKeyData:(NSData *) key
{
   NSMutableData   *data;

   data = [self mutableCopy];
   [data blowfishDecryptWithKey:key];
   return( [data autorelease]);
}


- (NSData *) twofishEncryptedDataWithKey:(MulleCipherTwofishKey *) key
                       withInitialValues:(NSData *) data
{
   twofish_ctx    ci;			/* keeps mode (ECB, CBC) and IV */
   NSMutableData  *dst;
   unsigned int   len;
   unsigned int   taillen;
   unsigned char  leftover[ BLOCK_SIZE / 8];
   unsigned char  *p;
   unsigned char  *q;

   if( data && [data length] != sizeof( ci.iv32))
      [NSException raise:MulleCipherCryptoException
                  format:@"%@: Invalid IV block", self, key];
   if( [key isForDecryption])
      [NSException raise:MulleCipherCryptoException
                  format:@"%@: You can not use a decryption key %@ for encrpytion", self, key];

   if( twofish_init( &ci, MulleCipherTwofishCBC, NULL) != TRUE)
      [NSException raise:MulleCipherCryptoException
                  format:@"%@: something is just not worrking out ???", self];
   
   len = [self length];
   p   = (void *) [self bytes];
   dst = [NSMutableData dataWithLength:(len + BLOCK_SIZE / 8 - 1) & ~(BLOCK_SIZE / 8 - 1)];
   q   = (void *) [dst bytes];

   /* decrypt the bytes */
   taillen = len % (BLOCK_SIZE / 8);
   if( taillen)
   {
      len -= taillen;
      memset( leftover, 0, sizeof( leftover));
      memcpy( leftover, &p[ len], taillen);
   }

   // init to "default" if no IV is supplied values
   if( data)
      memcpy( &ci.iv32, [data bytes], sizeof( ci.iv32));
   else
      memset( &ci.iv32, 0, sizeof( ci.iv32));

   if ( (twofish_block_encrypt( &ci, (void *) [key bytes],
                                (void *) p, len * 8, (void *) q) != len * 8) ||
        taillen && (twofish_block_encrypt( &ci, (void *) [key bytes],
                                (void *) leftover, BLOCK_SIZE, (void *) &q[ len]) != BLOCK_SIZE))

   {
      [NSException raise:MulleCipherCryptoException
                  format:@"Encrpytion failed unexpectedly"];
   }
   
   return( dst);
}


- (NSData *) twofishEncryptedDataWithKey:(MulleCipherTwofishKey *) key
{
   return( [self twofishEncryptedDataWithKey:key
                           withInitialValues:nil]);
}

//
// the encoded data is always block aligned, so we do not need to consider
// "uneven" data from the start
//
- (NSData *) twofishDecryptedDataWithKey:(MulleCipherTwofishKey *) key
                       withInitialValues:(NSData *) data
{
   twofish_ctx     ci;			/* keeps mode (ECB, CBC) and IV */
   NSMutableData   *dst;
   unsigned int    len;
   unsigned char   *p;
   unsigned char   *q;

   if( data && [data length] != sizeof( ci.iv32))
      [NSException raise:MulleCipherCryptoException
                  format:@"%@: Invalid IV block", self, key];
      
   if( ! [key isForDecryption])
      [NSException raise:MulleCipherCryptoException
                  format:@"%@: You can not use a encryption key %@ for decrpytion", self, key];

   if( twofish_init( &ci, MulleCipherTwofishCBC, NULL) != TRUE)
      [NSException raise:MulleCipherCryptoException
                  format:@"Internal error in %@", self];

   len = [self length];
   p   = (void *) [self bytes];
   dst = [NSMutableData dataWithLength:len];
   q   = (void *) [dst bytes];

   /* decrypt the bytes */
   if( len & ((BLOCK_SIZE / 8) - 1))
       [NSException raise:MulleCipherCryptoException
                   format:@"Data is truncated ciphertext or not encrypted at all"]; 

   // init to "default" if no IV is supplied values
   if( data)
      memcpy( &ci.iv32, [data bytes], sizeof( ci.iv32));
   else
      memset( &ci.iv32, 0, sizeof( ci.iv32));

   if ( (twofish_block_decrypt( &ci, (void *) [key bytes],
                                (void *) p, len * 8, (void *) q) != len * 8))
   {
      [NSException raise:MulleCipherCryptoException
                  format:@"Decrpytion failed unexpectedly"];
   }
   
   return( dst);
}


- (NSData *) twofishDecryptedDataWithKey:(MulleCipherTwofishKey *) key
{
   return( [self twofishDecryptedDataWithKey:key
                           withInitialValues:nil]);
}
#endif


@end
