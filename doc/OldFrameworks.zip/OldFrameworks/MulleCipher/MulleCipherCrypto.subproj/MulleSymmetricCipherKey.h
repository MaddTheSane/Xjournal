/*
 *  (C) Copyright 2000 Mulle kybernetiK. All rights reserved. 
 * 
 *  Permission to use, copy, modify and distribute this software and its
 *  documentation is hereby granted, provided that both the copyright
 *  notice and this permission notice appear in all copies of the
 *  software, derivative works or modified versions, and any portions
 *  thereof, and that both notices appear in supporting documentation, 
 *  and that credit is given to Mulle kybernetiK in all documents and
 *  publicity pertaining to direct or indirect use of this code or its
 *  derivatives. 
 * 
 *  THIS IS EXPERIMENTAL SOFTWARE AND IT IS KNOWN TO HAVE BUGS, SOME OF
 *  WHICH MAY HAVE SERIOUS CONSEQUENCES. THE COPYRIGHT HOLDER ALLOWS FREE
 *  USE OF THIS SOFTWARE IN ITS "AS IS" CONDITION. THE COPYRIGHT HOLDER
 *  DISCLAIMS ANY LIABILITY OF ANY KIND FOR ANY DAMAGES WHATSOEVER
 *  RESULTING DIRECTLY OR INDIRECTLY FROM THE USE OF THIS SOFTWARE OR OF
 *  ANY DERIVATIVE WORK.
 *
 *  Coded by Nat!
 *
 *  $Id: MulleSymmetricCipherKey.h,v 1.1.1.1 2001/02/22 14:55:31 znek Exp $
 *
 *  $Log: MulleSymmetricCipherKey.h,v $
 *  Revision 1.1.1.1  2001/02/22 14:55:31  znek
 *  Re-import of Nat!'s cryptographic framework. This version has been
 *  ported to MOSX, MOSXS and Solaris. It uses an extended build process
 *  similar to EDCommon & friends.
 *
 *  Revision 1.1.1.1  1970/01/01 22:37:33  nat
 *  Mercyful Release
 *
 */

#import <Foundation/Foundation.h>

typedef enum
{
   MulleCipherForBoth       = 0,
   MulleCipherForEncryption = 1,
   MulleCipherForDecryption = 2
} MulleSymmetricCipherKeyType;



@interface MulleSymmetricCipherKey : NSData  
{
   MulleSymmetricCipherKeyType  keyType;
   BOOL  isDestroyed;
          
   unsigned int   length;
}

// you usually only need to override the next two implementations.
+ (unsigned int) minKeyLength;
+ (unsigned int) maxKeyLength;

// if your key is a bit more involved, than a plain NSData, then you
// need to override this as well. If adding a few instance variables
// but keeping the NSData just wont do, I am afraid you have to do
// it all by yourself (somehow :). Check MulleCipherTwofish.m for an
// example...
// The direction parameter indicates, if the incoming key will be
// used for encryption or decryption. It is an error to pass in
// MulleCipherForBoth! It is not an error for the subclass to change
// the type to MulleCipherForBoth...
//
+ (id) keyWithData:(NSData *) data
     forDirection:(MulleSymmetricCipherKeyType) type;

//
// in general, if your subclass does not put the key data behind
// the object as in this implementation, it would be a good idea
// to override all the other implementations as well!
//
- (BOOL) isForEncryption;  // if NO, MUST be for decryption!
- (BOOL) isForDecryption;
- (NSData *) data;
- (const void *) bytes;
- (unsigned int) length;
- (void) destroy;

@end
