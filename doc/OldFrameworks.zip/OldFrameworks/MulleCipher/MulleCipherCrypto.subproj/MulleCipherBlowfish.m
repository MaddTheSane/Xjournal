/*
 *  (C) Copyright 2000 Mulle kybernetiK. All rights reserved. 
 * 
 *  Permission to use, copy, modify and distribute this software and its
 *  documentation is hereby granted, provided that both the copyright
 *  notice and this permission notice appear in all copies of the
 *  software, derivative works or modified versions, and any portions
 *  thereof, and that both notices appear in supporting documentation, 
 *  and that credit is given to Mulle kybernetiK in all documents and
 *  publicity pertaining to direct or indirect use of this code or its
 *  derivatives. 
 * 
 *  THIS IS EXPERIMENTAL SOFTWARE AND IT IS KNOWN TO HAVE BUGS, SOME OF
 *  WHICH MAY HAVE SERIOUS CONSEQUENCES. THE COPYRIGHT HOLDER ALLOWS FREE
 *  USE OF THIS SOFTWARE IN ITS "AS IS" CONDITION. THE COPYRIGHT HOLDER
 *  DISCLAIMS ANY LIABILITY OF ANY KIND FOR ANY DAMAGES WHATSOEVER
 *  RESULTING DIRECTLY OR INDIRECTLY FROM THE USE OF THIS SOFTWARE OR OF
 *  ANY DERIVATIVE WORK.
 *
 *  Coded by Nat!
 *
 *  $Id: MulleCipherBlowfish.m,v 1.1.1.1 2001/02/22 14:55:31 znek Exp $
 *
 *  $Log: MulleCipherBlowfish.m,v $
 *  Revision 1.1.1.1  2001/02/22 14:55:31  znek
 *  Re-import of Nat!'s cryptographic framework. This version has been
 *  ported to MOSX, MOSXS and Solaris. It uses an extended build process
 *  similar to EDCommon & friends.
 *
 *  Revision 1.1.1.1  1970/01/01 22:37:32  nat
 *  Mercyful Release
 *
 */

#import "MulleCipherCryptoException.h"
#import "MulleCipherBlowfish.h"
#import "MulleCipherBlowfishKey.h"
#import "MulleMersenneTwister.h"


#include "blowfish.h"

#define ASSUME_MODERN_CPU  1


@implementation MulleCipherBlowfish

+ (id) sharedInstance
{
   static id sharedInstance;

   if( ! sharedInstance)
      sharedInstance = [[self alloc] init];
   return( sharedInstance);
}


+ (void) load
{
   static BOOL   flag;
   
   if( flag)
      return;

   [self registerCipher:[self sharedInstance]];
   flag = YES;
}


- (NSString *) name
{
   return( @"Blowfish");
}


- (Class) keyClass
{
   return( [MulleCipherBlowfishKey class]);
}


//- (BOOL) lengthEncodingNeeded;
- (unsigned int) blockingFactor
{
   return( sizeof( unsigned int [ 2]));
}


- (BOOL) mutableDataMethodsAreFast
{
   return( YES);
}


- (BOOL) immutableDataMethodsAreFast
{
   return( NO);
}



void  MulleCipherBlowfishEncrypt( NSMutableData *data, blowfish_ctx *context)
{
   unsigned long   lr[ 2];
   unsigned int    i;
   unsigned int    n;
   unsigned int    runs;
   unsigned char   *p;
   unsigned char   *old;
   
   n = [data length];
   old = p = (void *) [data bytes];
   runs = n / sizeof( lr);
   for( i = 0; i < runs; i++)
   {
#if ASSUME_MODERN_CPU
      blowfish_encrypt( context, (unsigned long *) p, (unsigned long *) p + 1);
#else
      memcpy( lr, p, sizeof( lr));
      blowfish_encrypt( context, &lr[ 0], &lr[ 1]);
      memcpy( p, lr, sizeof( lr));
#endif
      p += sizeof( lr);
   }

   if( n -= runs * sizeof( lr))
   {
      MulleCipherRandomizeSmallBlockContents( (void *) lr, sizeof( lr));
      memcpy( lr, p, n);
      blowfish_encrypt( context, &lr[ 0], &lr[ 1]);
//      
// can't lose those blowfish bytes. proper in place encryption
// is not possible with blowfish, when the data is not length aligned
//
      
      [data increaseLengthBy:sizeof( lr) - n];
      p = &((unsigned char *) [data bytes])[ p - old];
      memcpy( p, lr, sizeof( lr));
   }
}



void   MulleCipherBlowfishDecrypt( NSMutableData *data, blowfish_ctx *context)
{
   unsigned long   lr[ 2];
   unsigned int    i;
   unsigned int    n;
   unsigned int    runs;
   unsigned char   *p;

   n = [data length];
   p = (void *) [data bytes];
   runs = n / sizeof( lr);
   for( i = 0; i < runs; i++)
   {
#if ASSUME_MODERN_CPU
      blowfish_decrypt( context, (unsigned long *) p, (unsigned long *) p + 1);
#else
      memcpy( lr, p, sizeof( lr));
      blowfish_decrypt( context, &lr[ 0], &lr[ 1]);
      memcpy( p, lr, sizeof( lr));
#endif
      p += sizeof( lr);
   }
#if DEBUG
   if( n -= runs * sizeof( lr))
   {
      NSCAssert( false, @"Blowfish data improperly blocked. Trailing size info ?");
#if 0      
      memset( lr, 0, sizeof( lr));	  // in v1.0 randomize this
      memcpy( lr, p, n);
      blowfish_decrypt( context, &lr[ 0], &lr[ 1]);
      memcpy( p, lr, n);
#endif      
   }
#endif   
}


//
// initial values are unused in blowfish
//
- (void) encryptData:(NSMutableData *) data
             withKey:(MulleSymmetricCipherKey *) key
   withInitialValues:(NSData *) values
{
#if DEBUG
   NSAssert( [data isKindOfClass:[NSMutableData class]], @"loss1");
   NSAssert( [key isKindOfClass:[MulleCipherBlowfishKey class]], @"loss2");
#endif
   MulleCipherBlowfishEncrypt( data, (blowfish_ctx *) [key bytes]);
}


- (void) decryptData:(NSMutableData *) data
             withKey:(MulleSymmetricCipherKey *) key
   withInitialValues:(NSData *) values
{
#if DEBUG
   NSAssert( [data isKindOfClass:[NSMutableData class]], @"loss1");
   NSAssert( [key isKindOfClass:[MulleCipherBlowfishKey class]], @"loss2");
#endif

   MulleCipherBlowfishDecrypt( data, (blowfish_ctx *) [key bytes]);
}


//
// doing this with a mutableCopy means that we have
// one extraneous memory access per word
//
- (NSData *) encryptedData:(NSData *) data
                   withKey:(MulleSymmetricCipherKey *) key
         withInitialValues:(NSData *) values
{
   NSMutableData   *copy;

#if DEBUG
   NSAssert( [data isKindOfClass:[NSData class]], @"loss1");
   NSAssert( [key isKindOfClass:[MulleCipherBlowfishKey class]], @"loss2");
#endif
   
   copy = [[data mutableCopy] autorelease];
   MulleCipherBlowfishEncrypt( copy, (blowfish_ctx *)  [key bytes]);
   return( copy);
}


- (NSData *) decryptedData:(NSData *) data
                   withKey:(MulleSymmetricCipherKey *) key
         withInitialValues:(NSData *) values
{
   NSMutableData   *copy;

#if DEBUG
   NSAssert( [data isKindOfClass:[NSData class]], @"loss1");
   NSAssert( [key isKindOfClass:[MulleCipherBlowfishKey class]], @"loss2");
#endif

   copy = [[data mutableCopy] autorelease];
   MulleCipherBlowfishDecrypt( copy, (blowfish_ctx *) [key bytes]);
   return( copy);
}

@end
