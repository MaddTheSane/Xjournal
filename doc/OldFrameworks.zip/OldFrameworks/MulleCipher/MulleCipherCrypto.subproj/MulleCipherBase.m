/*
 *  (C) Copyright 2000 Mulle kybernetiK. All rights reserved. 
 * 
 *  Permission to use, copy, modify and distribute this software and its
 *  documentation is hereby granted, provided that both the copyright
 *  notice and this permission notice appear in all copies of the
 *  software, derivative works or modified versions, and any portions
 *  thereof, and that both notices appear in supporting documentation, 
 *  and that credit is given to Mulle kybernetiK in all documents and
 *  publicity pertaining to direct or indirect use of this code or its
 *  derivatives. 
 * 
 *  THIS IS EXPERIMENTAL SOFTWARE AND IT IS KNOWN TO HAVE BUGS, SOME OF
 *  WHICH MAY HAVE SERIOUS CONSEQUENCES. THE COPYRIGHT HOLDER ALLOWS FREE
 *  USE OF THIS SOFTWARE IN ITS "AS IS" CONDITION. THE COPYRIGHT HOLDER
 *  DISCLAIMS ANY LIABILITY OF ANY KIND FOR ANY DAMAGES WHATSOEVER
 *  RESULTING DIRECTLY OR INDIRECTLY FROM THE USE OF THIS SOFTWARE OR OF
 *  ANY DERIVATIVE WORK.
 *
 *  Coded by Nat!
 *
 *  $Id: MulleCipherBase.m,v 1.1.1.1 2001/02/22 14:55:31 znek Exp $
 *
 *  $Log: MulleCipherBase.m,v $
 *  Revision 1.1.1.1  2001/02/22 14:55:31  znek
 *  Re-import of Nat!'s cryptographic framework. This version has been
 *  ported to MOSX, MOSXS and Solaris. It uses an extended build process
 *  similar to EDCommon & friends.
 *
 *  Revision 1.1.1.1  1970/01/01 22:37:33  nat
 *  Mercyful Release
 *
 */

#import "MulleCipherBase.h"
#import "MulleMersenneTwister.h"


#define THREAD_SAFE  0


@implementation MulleCipherBase


#if THREAD_SAFE

static NSLock   *mersenneLock;

+ (void) goMultiThreaded:(NSNotification *) notification
{
#if DEBUG
   fprintf( stderr, "Application went multi-threaded\n");
#endif   
   mersenneLock = [[NSLock alloc] init];
}


+ (void) load
{
   NSAutoreleasePool  *pool;

   pool = [[NSAutoreleasePool alloc] init];
NS_DURING   
   [[NSNotificationCenter defaultCenter] addObserver:self
                                            selector:@selector( goMultiThreaded:)
                                                name:NSWillBecomeMultiThreadedNotification
                                              object:nil];
NS_HANDLER
   mersenneLock = [[NSLock alloc] init];
NS_ENDHANDLER   
   [pool release];
}

#endif


static unsigned int   MulleCipherSeed( unsigned int len)
{
   unsigned int  timeval;
   unsigned int  seed;

again:   
   timeval = (unsigned int) time( NULL);

   seed = ((timeval << 4) | (timeval >> (32 - 4))) ^ (timeval & ~(1 << 4));
   seed ^= 0xC173F14A;				    // some wily constant
   seed ^= (len << 9) ^ (len << 19) ^ (len << 29);  // length of padding
   seed ^= ((int) &len << 16) ^ (int) &len;	    // stack address

   if( ! seed)
   {
      sleep( 1);
      goto again;
   }

   return( seed);
}


void  MulleCipherRandomizeSmallBlockContents( void *buf, unsigned int len)
{
   static unsigned int   seed;		

   //
   // initialize with some fairly random value
   // current time, stack address, some wily constant, old buffer contents
   // [probably zero] and the length of the string
   //
   if( ! seed)
   {
      seed = MulleCipherSeed( len);
      srand( seed);
   }

#if MULLE_CIPHER_PARANOID
   (volatile unsigned int) seed = 0;
#endif
   while( len)
   {
      *((unsigned char *)buf)++ = rand();
      --len;
   }
}




//
// The MersenneTwister is not a cryptographically secure algorithm.
// At least its better than rand() :)
// Unfortunately compiled with -O2 this is just a smidgen
// faster than rand()!
//
void  MulleCipherRandomizeLargeBlockContents( void *buf, unsigned int len)
{
   static unsigned int                  seed;		// volatile: paranoia
   static MulleMersenneTwisterContext   context;

   //
   // using a lock and a static context, only to be reinitialized seldomly
   // is much much faster than using an auto context and reseeding it
   // this is also faster than reseeding srand() everytime, but it's slower
   // if srand is seeded only once.
   //
#if THREAD_SAFE
   if( mersenneLock)
      [mersenneLock lock];
#endif   

   //
   // initialize with some fairly random value
   // current time, stack address, some wily constant, old buffer contents
   // [probably zero] and the length of the string
   //
   if( ! seed)
   {
      seed = MulleCipherSeed( len);
      MulleMersenneTwisterSeed( &context, seed);
   }
   
#if MULLE_CIPHER_PARANOID   
   (volatile unsigned int) seed = 0;
#endif   
   while( len)
   {
      *((unsigned char *)buf)++ = MulleMersenneTwisterRandom( &context);
      --len;
   }
#if MULLE_CIPHER_PARANOID   
   memset( &context, 0, sizeof( context));	// paranoia
#endif
#if THREAD_SAFE
   if( mersenneLock)
      [mersenneLock unlock];
#endif   
}


void  MulleCipherRandomizeBlockContents( void *buf, unsigned int len)
{
   if( len < 1024)	// empirical value for Cube 450
      MulleCipherRandomizeSmallBlockContents( buf, len);
   else
      MulleCipherRandomizeLargeBlockContents( buf, len);
}

@end
