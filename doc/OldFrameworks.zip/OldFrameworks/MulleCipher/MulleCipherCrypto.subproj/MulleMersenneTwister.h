/*
 // This library is free software; you can redistribute it and/or modify it
 // under the terms of the GNU Library General Public License as published by
 // the Free Software Foundation (either version 2 of the License or, at your
 // option, any later version).  This library is distributed in the hope that
 // it will be useful, but WITHOUT ANY WARRANTY, without even the implied
 // warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See
 // the GNU Library General Public License for more details.  You should have
 // received a copy of the GNU Library General Public License along with this
 // library; if not, write to the Free Software Foundation, Inc., 59 Temple
 // Place, Suite 330, Boston, MA 02111-1307, USA.
 */
#import <Foundation/Foundation.h>


typedef struct
{
   unsigned int   state[ 624 + 1];   // state vector + 1 extra to not violate ANSI C
   unsigned int   *next;             // next random value is computed from here
   int            left;              // can *next++ this many times before reloading
} MulleMersenneTwisterContext; 



//
// Use it like this:
//
// - (void) myMethod
// {
// 	MulleMersenneTwisterContext   context;
//
//	MulleMersenneTwisterSeed( 0x1313, &context);
//      for(;;)
//	   printf( "%u ", MulleMersenneTwisterRandom( &context);
//
// Excerpt From the FAQ: To use as a random source for encryption.
// 
// The sequence is, as it is, not cryptographically secure. However, if you use an 
// appropriate Secure Hashing Algorithm (non-invertible function compressing several 
// words into one word), then you may use them. 
//
void           MulleMersenneTwisterSeed( MulleMersenneTwisterContext *context, unsigned int seed);
unsigned int   MulleMersenneTwisterReload( MulleMersenneTwisterContext *context);

static inline unsigned int  MulleMersenneTwisterRandom( MulleMersenneTwisterContext *context)
{
    unsigned int y;

    if( --context->left < 0)
       y = MulleMersenneTwisterReload( context);
    else
       y = *context->next++;

    y ^= (y >> 11);
    y ^= (y <<  7) & 0x9D2C5680U;
    y ^= (y << 15) & 0xEFC60000U;
    return( y ^ (y >> 18));
}
