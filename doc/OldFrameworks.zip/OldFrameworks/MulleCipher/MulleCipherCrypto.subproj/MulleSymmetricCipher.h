/*
 *  (C) Copyright 2000 Mulle kybernetiK. All rights reserved. 
 * 
 *  Permission to use, copy, modify and distribute this software and its
 *  documentation is hereby granted, provided that both the copyright
 *  notice and this permission notice appear in all copies of the
 *  software, derivative works or modified versions, and any portions
 *  thereof, and that both notices appear in supporting documentation, 
 *  and that credit is given to Mulle kybernetiK in all documents and
 *  publicity pertaining to direct or indirect use of this code or its
 *  derivatives. 
 * 
 *  THIS IS EXPERIMENTAL SOFTWARE AND IT IS KNOWN TO HAVE BUGS, SOME OF
 *  WHICH MAY HAVE SERIOUS CONSEQUENCES. THE COPYRIGHT HOLDER ALLOWS FREE
 *  USE OF THIS SOFTWARE IN ITS "AS IS" CONDITION. THE COPYRIGHT HOLDER
 *  DISCLAIMS ANY LIABILITY OF ANY KIND FOR ANY DAMAGES WHATSOEVER
 *  RESULTING DIRECTLY OR INDIRECTLY FROM THE USE OF THIS SOFTWARE OR OF
 *  ANY DERIVATIVE WORK.
 *
 *  Coded by Nat!
 *
 *  $Id: MulleSymmetricCipher.h,v 1.1.1.1 2001/02/22 14:55:31 znek Exp $
 *
 *  $Log: MulleSymmetricCipher.h,v $
 *  Revision 1.1.1.1  2001/02/22 14:55:31  znek
 *  Re-import of Nat!'s cryptographic framework. This version has been
 *  ported to MOSX, MOSXS and Solaris. It uses an extended build process
 *  similar to EDCommon & friends.
 *
 *  Revision 1.1.1.1  1970/01/01 22:37:32  nat
 *  Mercyful Release
 *
 *
 * Nat! recommends Smoke Blow from Kiel. Fine German Noise!
 * (ah the pleasures of amateur wares...)
 *
 * Ok first shot was just a small technical library or
 * a class collection. But when ZNeK and I accidentally 
 * hung out at my home, because I forgot that the Gathering 
 * concert was 2 days earlier <ARGH> ZNeK inspected the code 
 * - then ready for release and called it (using the proper 
 * terminus technicus) "lame".
 *
 * Oh hell, since I have the flu and can't code
 * really code anyway, lets just hack up a little abstract
 * wrapper around the wrapper....
 *
 */


#import "MulleCipherBase.h"


extern NSString  *MulleCipherPlaintextLength;
extern NSString  *MulleCipherCiphertext;


@class MulleSymmetricCipherKey;


#define MulleCipherPaddingFooterMagic   { 'V', 'f', 'L', 'B' }
#define MulleCipherPaddingFooterMajorVersion  1	   // compatibility. only change this if you mess with len
#define MulleCipherPaddingFooterMinorVersion  0	   // change this if you add fields (to the top)

// possible interesting addition: CRC / MD5 check
typedef struct
{
   unsigned char	lenMSB;		        // length of footer (including padding)
   unsigned char	lenLSB;
   unsigned char	versionMajor;		// version for additional fields "later"
   unsigned char	versionMinor;
   unsigned char	magic[ 4];		// 'VfLB'
} MulleCipherPaddingFooter;



// the base class hints at the possibility at future expansions. but
// for now you can safely ignore it (equate it with NSObject)
//
@interface MulleSymmetricCipher : MulleCipherBase
{
   // nothing in here...
}

//
// cipher algorithms register themselves at +load time, this is
// similiar to the way NSImageRep subclassess register themselves
//

// look for a registered "cipher" by name
+ (id) cipherWithName:(NSString *) name;

// register an instance(!) of a cipher algorithm (aka MulleSymmetricCipher subclass) here
+ (void) registerCipher:(MulleSymmetricCipher *) cipher;
+ (void) unregisterCipher:(MulleSymmetricCipher *) cipher;

// take a look at the registered ciphers. Objects and their names 
// will be in the same order. 
+ (NSArray *) registeredCiphers;
+ (NSArray *) registeredCipherNames;


//
//   U L T R A    C O N V E N I E N T   I N T E R F A C E
//
//      Give me convenience or give me death!
//
// These methods encrypt and decrypt data with a password. The encrypted
// data is stored in a dictionary with key MulleCipherCiphertext
// and it's plaintext length with key MulleCipherPlaintextLength
// On decryption the plaintext is recovered and the data set
// to the original plaintext length.
//
//
- (NSDictionary *) crypt:(NSData *) plaintext
                password:(NSData *) password;

- (NSData *) decrypt:(NSDictionary *) dictionary
            password:(NSData *) password;




//
//   C O N V E N I E N C E   I N T E R F A C E
//
//
// calls en/decryptedData:withKey:withInitialValues:
// with a zeroed out initialValues memory block of the
// appropriate size (determined by -sizeOfInitialValues)
//
// The decrypt methods may leave a small trail of random
// garbage on the decrypted plaintext, because of blocking.
// Therefore you store the size of the original plaintext
// along with the ciphertext and truncate the returned
// NSData accordingly.
//
- (NSData *) encryptedData:(NSData *) data
                   withKey:(MulleSymmetricCipherKey *) key;
- (NSData *) decryptedData:(NSData *) data
                   withKey:(MulleSymmetricCipherKey *) key;

- (void) encryptData:(NSMutableData *) data
             withKey:(MulleSymmetricCipherKey *) key;

- (void) decryptData:(NSMutableData *) data
             withKey:(MulleSymmetricCipherKey *) key;

//
// These methods store and retrieve the size of the plaintext
// in and from the ciphertext. The advantage is that if you 
// encrypt and decrypt binary data, the data will not suddenly
// become larger, due to the encryption blocking. The
// negative aspect is, that you lose compatilty, because
// non MulleCipher decoders will not be able to handle the
// MulleCipherPaddingFooter which is (in plaintext)
// appended to the ciphertext. Other decoders will still be
// able to decode, but will have garbage bytes at the end.
//
- (NSData *) encryptedDataWithFooter:(NSData *) data
                             withKey:(MulleSymmetricCipherKey *) key;
- (NSData *) decryptedDataWithFooter:(NSData *) data
                             withKey:(MulleSymmetricCipherKey *) key;


- (void) encryptDataWithFooter:(NSMutableData *) data
                       withKey:(MulleSymmetricCipherKey *) key;

- (void) decryptDataWithFooter:(NSMutableData *) data
                       withKey:(MulleSymmetricCipherKey *) key;

//
// find out if there is a padding footer on the ciphertext data
//
- (BOOL) hasFooterAppended:(NSData *) data;


//
//   A B S T R A C T   I N T E R F A C E
//
// THIS IS THE STUFF SUBCLASS IMPLEMENTORS CARE ABOUT
//
// default implementation raises. This is a short non-localized string like 
// "Blowfish" usually 
- (NSString *) name;

// default implementation raises. Subclasses return a subclass 
// of MulleSymmetricCipherKey here
- (Class) keyClass;

//
// default implementation returns 0 (bytes), depending on the
// algorithm, that may very well be OK. Initial values are a
// tough subject. Better read "Applied Cryptology"...
//
- (unsigned int) sizeOfInitialValues;

//
// hint, which en-/decrypt methods to use. default NO. Say YES, if you 
// implement mutable methods (do not rely on the default 
// implementation)
//
- (BOOL) mutableDataMethodsAreFast;

//
// hint, which methods to use. default YES. Either one must
// say yes. Both may also say yes.
//
- (BOOL) immutableDataMethodsAreFast;

//
// Do some generic length encoding (or not).
// a blocking factor of 1 means that no length Encoding is needed
// the blocking factor must be a power of two. If it is not, you need to
// override appendSizeInfoToPlaintext and removeSizeInfoFromPlaintext
// in your cipher class
//
- (unsigned int) blockingFactor;	// Default: 1

- (void) appendSizeInfoToPlaintext:(NSMutableData *) data
                   plaintextLength:(unsigned int) length;

//
// returns number of bytes in plaintext. removes possible footer from
// data. If there is no footer this will return [data length];
//
- (unsigned int) removeSizeInfoFromPlaintext:(NSMutableData *) data;


//
// encryptedData:withKey:withInitialValues:
// and decryptedData:withKey:withInitialValues:
//
// YOU MUST IMPLEMENT THESE TWO
//
//
// the base class will support all other calls, but does
// not make claims, that they are efficient in any way!
//
// encrypt all bytes in "data" with the given "key" using "values" as the
// initial crypting values. If you are unsure what initialValues are read
// the book (see above), or use just encryptData:withKey:
// You get the key, by first asking for the -keyClass and than manufacturing
// the key with + keyWithData:forDirection:
//
// if your subclass returns 0 to -sizeOfInitialValues, your cryption routines
// must be able to deal (-> ignore) values being nil
//
- (NSData *) encryptedData:(NSData *) data
                   withKey:(MulleSymmetricCipherKey *) key
         withInitialValues:(NSData *) values;

//
// just the reverse. you will need another key though!!
//
- (NSData *) decryptedData:(NSData *) data
                   withKey:(MulleSymmetricCipherKey *) key
         withInitialValues:(NSData *) values;


//
// Methods operating on NSMutableData will lengthen that data,
//
//	 you DONT NEED to implement THESE two
//
//
- (void) encryptData:(NSMutableData *) data
             withKey:(MulleSymmetricCipherKey *) key
   withInitialValues:(NSData *) values;


- (void) decryptData:(NSMutableData *) data
             withKey:(MulleSymmetricCipherKey *) key
   withInitialValues:(NSData *) values;



//
// The methods for encoding length at the end of the ciphertext
// should be preferably used with NSMutableData, since it will
// save some superflous copying in many cases.
//
// 	you should but DONT NEED to implement THESE two
//
// These methods pay off when using the withFooter methods
// 
- (void) encryptDataWithFooter:(NSMutableData *) data
                         withKey:(MulleSymmetricCipherKey *) key
               withInitialValues:(NSData *) values;


- (void) decryptDataWithFooter:(NSMutableData *) data
                         withKey:(MulleSymmetricCipherKey *) key
               withInitialValues:(NSData *) values;


//
// Methods operating on NSMutableData will lengthen that data,
//
//	 you DONT NEED to implement THESE two
//
//
- (NSData *) encryptedDataWithFooter:(NSData *) data
                             withKey:(MulleSymmetricCipherKey *) key
                   withInitialValues:(NSData *) values;

- (NSData *) decryptedDataWithFooter:(NSData *) data
                             withKey:(MulleSymmetricCipherKey *) key
                   withInitialValues:(NSData *) values;

@end
