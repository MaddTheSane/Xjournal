/*
 * (C) Copyright 2000 Mulle kybernetiK
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND MULLE KYBERNETIK DISCLAIMS
 * ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL MULLE KYBERNETIK
 * BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL
 * DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
 * PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS
 * ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
 * SOFTWARE.
 *
 * $Id: NSMutableData+MulleCipherCrpyto.m,v 1.1.1.1 2001/02/22 14:55:31 znek Exp $
 *
 * $Log: NSMutableData+MulleCipherCrpyto.m,v $
 * Revision 1.1.1.1  2001/02/22 14:55:31  znek
 * Re-import of Nat!'s cryptographic framework. This version has been
 * ported to MOSX, MOSXS and Solaris. It uses an extended build process
 * similar to EDCommon & friends.
 *
 * Revision 1.1.1.1  1970/01/01 22:37:32  nat
 * Mercyful Release
 *
 *
 */
#import "MulleCipherCryptoException.h"
#import "NSMutableData+MulleCipherCrpyto.h"
#include "blowfish.h"

#define ASSUME_MODERN_CPU  1


@implementation NSMutableData ( MulleCipherCrpyto)

#if 0 && THATS_HOW_IT_LOOKED_THE_FIRST_TIME_AROUND

- (void) blowfishEncryptWithKey:(NSData *) key;
{
   blowfish_ctx    context;
   unsigned long   lr[ 2];
   unsigned int    i;
   unsigned int    n;
   unsigned int    runs;
   unsigned char   *p;

   if( (n = [key length]) < 4 || n > BLOWFISH_MAX_KEY_BYTES)
      [NSException raise:MulleCipherCryptoException
                  format:@"Silly blowfish key %@", key];

   blowfish_init( &context, (unsigned char*) [key bytes], n);

   n = [self length];
   p = (void *) [self bytes];
   runs = n / sizeof( lr);
   for( i = 0; i < runs; i++)
   {
#if ASSUME_MODERN_CPU
      blowfish_encrypt( &context, (unsigned long *) p, (unsigned long *) p + 1);
#else
      memcpy( lr, p, sizeof( lr));
      blowfish_encrypt( &context, &lr[ 0], &lr[ 1]);
      memcpy( p, lr, sizeof( lr));
#endif
      p += sizeof( lr);
   }

   if( n -= runs * sizeof( lr))
   {

      memset( lr, 0, sizeof( lr));
      memcpy( lr, p, n);
      blowfish_encrypt( &context, &lr[ 0], &lr[ 1]);
//      
// can't lose those blowfish bytes. proper in place encryption
// is not possible with blowfish, when the data is not length aligned
//      
      [self appendBytes:&lr  // bogus
                 length:sizeof( lr) - n];
      memcpy( p, lr, sizeof( lr));
   }
}


- (void) blowfishDecryptWithKey:(NSData *) key
{
   blowfish_ctx    context;
   unsigned long   lr[ 2];
   unsigned int    i;
   unsigned int    n;
   unsigned int    runs;
   unsigned char   *p;

   if( (n = [key length]) < 1 || n > BLOWFISH_MAX_KEY_BYTES)  // who knows how others encode ?
      [NSException raise:MulleCipherCryptoException
                  format:@"Incompatible blowfish key %@", key];

   blowfish_init( &context, (unsigned char*) [key bytes], n);

   n = [self length];
   p = (void *) [self bytes];
   runs = n / sizeof( lr);
   for( i = 0; i < runs; i++)
   {
#if ASSUME_MODERN_CPU
      blowfish_decrypt( &context, (unsigned long *) p, (unsigned long *) p + 1);
#else
      memcpy( lr, p, sizeof( lr));
      blowfish_decrypt( &context, &lr[ 0], &lr[ 1]);
      memcpy( p, lr, sizeof( lr));
#endif
      p += sizeof( lr);
   }

   if( n -= runs * sizeof( lr))
   {
      memset( lr, 0, sizeof( lr));
      memcpy( lr, p, n);
      blowfish_decrypt( &context, &lr[ 0], &lr[ 1]);
      memcpy( p, lr, n);
   }
}

#endif


@end
