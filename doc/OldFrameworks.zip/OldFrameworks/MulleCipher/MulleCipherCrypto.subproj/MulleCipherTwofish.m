/*
 *  (C) Copyright 2000 Mulle kybernetiK. All rights reserved. 
 * 
 *  Permission to use, copy, modify and distribute this software and its
 *  documentation is hereby granted, provided that both the copyright
 *  notice and this permission notice appear in all copies of the
 *  software, derivative works or modified versions, and any portions
 *  thereof, and that both notices appear in supporting documentation, 
 *  and that credit is given to Mulle kybernetiK in all documents and
 *  publicity pertaining to direct or indirect use of this code or its
 *  derivatives. 
 * 
 *  THIS IS EXPERIMENTAL SOFTWARE AND IT IS KNOWN TO HAVE BUGS, SOME OF
 *  WHICH MAY HAVE SERIOUS CONSEQUENCES. THE COPYRIGHT HOLDER ALLOWS FREE
 *  USE OF THIS SOFTWARE IN ITS "AS IS" CONDITION. THE COPYRIGHT HOLDER
 *  DISCLAIMS ANY LIABILITY OF ANY KIND FOR ANY DAMAGES WHATSOEVER
 *  RESULTING DIRECTLY OR INDIRECTLY FROM THE USE OF THIS SOFTWARE OR OF
 *  ANY DERIVATIVE WORK.
 *
 *  Coded by Nat!
 *
 *  $Id: MulleCipherTwofish.m,v 1.1.1.1 2001/02/22 14:55:31 znek Exp $
 *
 *  $Log: MulleCipherTwofish.m,v $
 *  Revision 1.1.1.1  2001/02/22 14:55:31  znek
 *  Re-import of Nat!'s cryptographic framework. This version has been
 *  ported to MOSX, MOSXS and Solaris. It uses an extended build process
 *  similar to EDCommon & friends.
 *
 *  Revision 1.1.1.1  1970/01/01 22:37:32  nat
 *  Mercyful Release
 *
 */

#import "MulleCipherTwofish.h"
#import "MulleCipherTwofishKey.h"
#import "MulleSymmetricCipherKey.h"
#import "MulleCipherCryptoException.h"
#include "aes.h"


typedef enum
{
   MulleCipherTwofishECB  = 1,
   MulleCipherTwofishCBC  = 2,
   MulleCipherTwofishCFB1 = 3
} MulleCipherTwofishMode;



@implementation MulleCipherTwofish

+ (id) sharedInstance
{
   static id sharedInstance;

   if( ! sharedInstance)
      sharedInstance = [[self alloc] init];
   return( sharedInstance);
}


+ (void) load
{
   static BOOL   flag;
   
   if( flag)
      return;

   [self registerCipher:[self sharedInstance]];
   flag = YES;
}


- (NSString *) name
{
   return( @"Twofish");
}


- (unsigned int) blockingFactor
{
   return( BLOCK_SIZE / 8);
}


- (Class) keyClass
{
   return( [MulleCipherTwofishKey class]);
}


- (unsigned int) sizeOfInitialValues
{
   twofish_ctx    ci; //pathetic
   
   return( sizeof( ci.iv32));
}


- (NSData *) encryptedData:(NSData *) data
                   withKey:(MulleSymmetricCipherKey *) key
         withInitialValues:(NSData *) values
{
   twofish_ctx    ci;			/* keeps mode (ECB, CBC) and IV */
   NSMutableData  *dst;
   unsigned int   len;
   unsigned int   taillen;
   unsigned char  leftover[ BLOCK_SIZE / 8];
   unsigned char  *p;
   unsigned char  *q;

#if DEBUG
   NSAssert( [data isKindOfClass:[NSData class]], @"loss1");
   NSAssert( [key isKindOfClass:[MulleCipherTwofishKey class]], @"loss2");
   NSAssert( ! values || [values isKindOfClass:[NSData class]], @"loss3");

   if( values && [values length] != sizeof( ci.iv32))
      [NSException raise:MulleCipherCryptoException
                  format:@"%@: Invalid IV block %@", self, values];
   if( ! [key isForEncryption])
      [NSException raise:MulleCipherCryptoException
                  format:@"%@: You can not use a decryption key %@ for encrpytion", self, key];
#endif

   // only CBC makes sense in this framework (AFAICT)
   if( twofish_init( &ci, MulleCipherTwofishCBC, NULL) != TRUE)
      [NSException raise:MulleCipherCryptoException
                  format:@"%@: something is just not working out ???", self];
   
   // init to "default" if no IV is supplied values
   if( values)
      memcpy( &ci.iv32, [values bytes], sizeof( ci.iv32));
   else
      memset( &ci.iv32, 0, sizeof( ci.iv32));

   len = [data length];
   p   = (void *) [data bytes];
   dst = [NSMutableData dataWithLength:(len + BLOCK_SIZE / 8 - 1) & ~(BLOCK_SIZE / 8 - 1)];
   q   = (void *) [dst bytes];

   /* decrypt the bytes */
   taillen = len % (BLOCK_SIZE / 8);
   if( taillen)
   {
      len -= taillen;
      MulleCipherRandomizeSmallBlockContents( leftover, sizeof( leftover));
      memcpy( leftover, &p[ len], taillen);
   }

   if ( (twofish_block_encrypt( &ci, (void *) [key bytes],
                                (void *) p, len * 8, (void *) q) != len * 8) ||
        taillen && (twofish_block_encrypt( &ci, (void *) [key bytes],
                                (void *) leftover, BLOCK_SIZE, (void *) &q[ len]) != BLOCK_SIZE))

   {
      [NSException raise:MulleCipherCryptoException
                  format:@"Encrpytion failed unexpectedly"];
   }
   
   return( dst);
}


//
// the encoded data is always block aligned, so we do not need to consider
// "uneven" data from the start
//
- (NSData *) decryptedData:(NSData *) data
                   withKey:(MulleSymmetricCipherKey *) key
         withInitialValues:(NSData *) values
{
   twofish_ctx     ci;			/* keeps mode (ECB, CBC) and IV */
   NSMutableData   *dst;
   unsigned int    len;
   unsigned char   *p;
   unsigned char   *q;

#if DEBUG
   NSAssert( [data isKindOfClass:[NSData class]], @"loss1");
   NSAssert( [key isKindOfClass:[MulleCipherTwofishKey class]], @"loss2");
   NSAssert( ! values || [values isKindOfClass:[NSData class]], @"loss3");

   if( values && [values length] != sizeof( ci.iv32))
      [NSException raise:MulleCipherCryptoException
                  format:@"%@: Invalid IV block %@", self, values];
      
   if( [key isForEncryption])
      [NSException raise:MulleCipherCryptoException
                  format:@"%@: You can not use a encryption key %@ for decrpytion", self, key];
#endif
   // only CBC makes sense in this framework (AFAICT)
   if( twofish_init( &ci, MulleCipherTwofishCBC, NULL) != TRUE)
      [NSException raise:MulleCipherCryptoException
                  format:@"Internal error in %@", self];

  // init to "default" if no IV is supplied values
   if( values)
      memcpy( &ci.iv32, [values bytes], sizeof( ci.iv32));
   else
      memset( &ci.iv32, 0, sizeof( ci.iv32));

   len = [data length];
   if( len & ((BLOCK_SIZE / 8) - 1))
       [NSException raise:MulleCipherCryptoException
                   format:@"Data is truncated ciphertext or not encrypted at all"]; 

   p   = (void *) [data bytes];
   dst = [NSMutableData dataWithLength:len];
   q   = (void *) [dst bytes];

   /* decrypt the bytes */
   if ( (twofish_block_decrypt( &ci, (void *) [key bytes],
                                (void *) p, len * 8, (void *) q) != len * 8))
   {
      [NSException raise:MulleCipherCryptoException
                  format:@"Decrpytion failed unexpectedly"];
   }
   
   return( dst);
}



@end
