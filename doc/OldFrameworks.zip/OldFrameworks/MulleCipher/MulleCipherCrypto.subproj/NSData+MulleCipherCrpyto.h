/*
 *  (C) Copyright 2000 Mulle kybernetiK. All rights reserved. 
 * 
 *  Permission to use, copy, modify and distribute this software and its documentation 
 *  is hereby granted, provided that both the copyright notice and this permission 
 *  notice appear in all copies of the software, derivative works or modified versions, 
 *  and any portions thereof, and that both notices appear in supporting documentation, 
 *  and that credit is given to Mulle kybernetiK in all documents and publicity 
 *  pertaining to direct or indirect use of this code or its derivatives. 
 * 
 *  THIS IS EXPERIMENTAL SOFTWARE AND IT IS KNOWN TO HAVE BUGS, SOME OF WHICH MAY HAVE 
 *  SERIOUS CONSEQUENCES. THE COPYRIGHT HOLDER ALLOWS FREE USE OF THIS SOFTWARE IN ITS 
 *  "AS IS" CONDITION. THE COPYRIGHT HOLDER DISCLAIMS ANY LIABILITY OF ANY KIND FOR ANY 
 *  DAMAGES WHATSOEVER RESULTING DIRECTLY OR INDIRECTLY FROM THE USE OF THIS SOFTWARE 
 *  OR OF ANY DERIVATIVE WORK.
 *
 *  Coded by Nat!
 *
 *  $Id: NSData+MulleCipherCrpyto.h,v 1.1.1.1 2001/02/22 14:55:31 znek Exp $
 *
 *  $Log: NSData+MulleCipherCrpyto.h,v $
 *  Revision 1.1.1.1  2001/02/22 14:55:31  znek
 *  Re-import of Nat!'s cryptographic framework. This version has been
 *  ported to MOSX, MOSXS and Solaris. It uses an extended build process
 *  similar to EDCommon & friends.
 *
 *  Revision 1.1.1.1  1970/01/01 22:37:32  nat
 *  Mercyful Release
 *
 */
#import <Foundation/Foundation.h>


@class MulleCipherTwofishKey;


@interface NSData ( MulleCipherCrpyto)

//
// The key supplied should be between 4 and 56 bytes
// To get a string encrypted use NSString's dataUsingEncoding: call
// to getr data. Use initWithData:encoding: to get the data back into
// a NSString
// After en-/decryption destroy (zero out) your key data immediately
//
- (NSData *) blowfishEncryptedDataWithKeyData:(NSData *) key;
- (NSData *) blowfishDecryptedDataWithKeyData:(NSData *) key;

//
// TwoFish keys must be made beforehand. There is a class MulleCipherTwoFishKey
// that provides you with a key. That key must have been made for encryption.
// For real security ensure, that your key is random through all bits.
//
// Encryption mode is chained block cipher with the IV set to all zeroes
// initially. The reason for that being, that it should be the most
// portable across different implementations, assuming that all zeroes
// is the default starting state
// After encryption destroy or release your key immediately
//
- (NSData *) twofishEncryptedDataWithKey:(MulleCipherTwofishKey *) key;
- (NSData *) twofishEncryptedDataWithKey:(MulleCipherTwofishKey *) key
                       withInitialValues:(NSData *) data;

//
// That key must have been made for decryption. You can not reuse your
// encryption key.
//
- (NSData *) twofishDecryptedDataWithKey:(MulleCipherTwofishKey *) key;
- (NSData *) twofishDecryptedDataWithKey:(MulleCipherTwofishKey *) key
                       withInitialValues:(NSData *) data;

@end

