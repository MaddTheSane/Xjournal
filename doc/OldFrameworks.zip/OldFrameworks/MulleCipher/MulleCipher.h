/*
 *  (C) Copyright 2000 Mulle kybernetiK. All rights reserved. 
 * 
 *  Permission to use, copy, modify and distribute this software and its
 *  documentation is hereby granted, provided that both the copyright
 *  notice and this permission notice appear in all copies of the
 *  software, derivative works or modified versions, and any portions
 *  thereof, and that both notices appear in supporting documentation, 
 *  and that credit is given to Mulle kybernetiK in all documents and
 *  publicity pertaining to direct or indirect use of this code or its
 *  derivatives. 
 * 
 *  THIS IS EXPERIMENTAL SOFTWARE AND IT IS KNOWN TO HAVE BUGS, SOME OF
 *  WHICH MAY HAVE SERIOUS CONSEQUENCES. THE COPYRIGHT HOLDER ALLOWS FREE
 *  USE OF THIS SOFTWARE IN ITS "AS IS" CONDITION. THE COPYRIGHT HOLDER
 *  DISCLAIMS ANY LIABILITY OF ANY KIND FOR ANY DAMAGES WHATSOEVER
 *  RESULTING DIRECTLY OR INDIRECTLY FROM THE USE OF THIS SOFTWARE OR OF
 *  ANY DERIVATIVE WORK.
 *
 *  Coded by Nat!
 *
 *  All the actual Digest/Encryption routines have been written by other
 *  people and they have made them available for unrestricted use. Please
 *  when in doubt check the individual notices in those sources or their
 *  respective websites.
 *
 *  Blowfish and Twofish originated from www.counterpane.com
 *  MD5 SHA1, though originally from RSA, was procured via www.isc.org.
 *  These specific implementations are public domain, though ISC put their
 *  Copyright on top.
 *  CRC32 by Gary S. Brown
 *  Some of the sources have been modified a bit cosmetically and in naming
 *  of functions and structures, to make the Framework more readable and
 *  predicatable in terms of C-namespace usage.
 *
 *  This Framework compiled and runs under Mac OS X (PPC). YellowBox on
 *  Windows in particular has not been tested (and may therefore not work)
 *
 *  $Id: MulleCipher.h,v 1.1.1.1 2001/02/22 14:55:31 znek Exp $
 *
 *  $Log: MulleCipher.h,v $
 *  Revision 1.1.1.1  2001/02/22 14:55:31  znek
 *  Re-import of Nat!'s cryptographic framework. This version has been
 *  ported to MOSX, MOSXS and Solaris. It uses an extended build process
 *  similar to EDCommon & friends.
 *
 *  Revision 1.1.1.1  1970/01/01 22:37:32  nat
 *  Mercyful Release
 *
 */

// the MulleCipherCrypto Subproject
#import "MulleCipherCryptoException.h"
#import "MulleSymmetricCipher.h"
#import "MulleSymmetricCipherKey.h"

// the MulleCipherDigest Subproject
#import "MulleCipherDigestException.h"
#import "NSData+MulleCipherDigests.h"
