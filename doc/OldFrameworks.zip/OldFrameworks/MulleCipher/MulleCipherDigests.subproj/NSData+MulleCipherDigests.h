/*
 *  (C) Copyright 2000 Mulle kybernetiK. All rights reserved. 
 * 
 *  Permission to use, copy, modify and distribute this software and its
 *  documentation is hereby granted, provided that both the copyright
 *  notice and this permission notice appear in all copies of the
 *  software, derivative works or modified versions, and any portions
 *  thereof, and that both notices appear in supporting documentation, 
 *  and that credit is given to Mulle kybernetiK in all documents and
 *  publicity pertaining to direct or indirect use of this code or its
 *  derivatives. 
 * 
 *  THIS IS EXPERIMENTAL SOFTWARE AND IT IS KNOWN TO HAVE BUGS, SOME OF
 *  WHICH MAY HAVE SERIOUS CONSEQUENCES. THE COPYRIGHT HOLDER ALLOWS FREE
 *  USE OF THIS SOFTWARE IN ITS "AS IS" CONDITION. THE COPYRIGHT HOLDER
 *  DISCLAIMS ANY LIABILITY OF ANY KIND FOR ANY DAMAGES WHATSOEVER
 *  RESULTING DIRECTLY OR INDIRECTLY FROM THE USE OF THIS SOFTWARE OR OF
 *  ANY DERIVATIVE WORK.
 *
 *  Coded by Nat!
 *
 *  $Id: NSData+MulleCipherDigests.h,v 1.1.1.1 2001/02/22 14:55:32 znek Exp $
 *
 *  $Log: NSData+MulleCipherDigests.h,v $
 *  Revision 1.1.1.1  2001/02/22 14:55:32  znek
 *  Re-import of Nat!'s cryptographic framework. This version has been
 *  ported to MOSX, MOSXS and Solaris. It uses an extended build process
 *  similar to EDCommon & friends.
 *
 *  Revision 1.1.1.1  1970/01/01 22:37:33  nat
 *  Mercyful Release
 *
 */

#import <Foundation/Foundation.h>

//
// digests are pretty techincal in nature. I believe there is no real
// application, where a user decides "I want to use that digest" it
// is a programmers choice. Therefore there's no abstract interface
// here...

@interface NSData ( MulleCipher)

//
// returns the MD5 Digest wrapped in another NSData.
// the returned data will always be 16 bytes long
//
- (NSData *) md5Digest;

//
// This a sort of scatter/gather implementation, when
// your data to be digested is spread over several
// NSDatas
//
+ (NSData *) md5DigestForDatas:(NSArray *) array;


//
// returns the SHA1 Digest wrapped in another NSData.
// the returned data will always be 20 bytes long
//
- (NSData *) sha1Digest;

//
// scatter/gather kind of method. Input is an array
// of NSDatas
//
+ (NSData *) sha1DigestForDatas:(NSArray *) array;

//
// CRC32. This is fine for integrity checks, but
// for not much more. 
//
- (unsigned long) crc32;

@end
