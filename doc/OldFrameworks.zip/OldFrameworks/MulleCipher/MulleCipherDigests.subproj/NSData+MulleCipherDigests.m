/*
 *  (C) Copyright 2000 Mulle kybernetiK. All rights reserved. 
 * 
 *  Permission to use, copy, modify and distribute this software and its documentation 
 *  is hereby granted, provided that both the copyright notice and this permission 
 *  notice appear in all copies of the software, derivative works or modified versions, 
 *  and any portions thereof, and that both notices appear in supporting documentation, 
 *  and that credit is given to Mulle kybernetiK in all documents and publicity 
 *  pertaining to direct or indirect use of this code or its derivatives. 
 * 
 *  THIS IS EXPERIMENTAL SOFTWARE AND IT IS KNOWN TO HAVE BUGS, SOME OF WHICH MAY HAVE 
 *  SERIOUS CONSEQUENCES. THE COPYRIGHT HOLDER ALLOWS FREE USE OF THIS SOFTWARE IN ITS 
 *  "AS IS" CONDITION. THE COPYRIGHT HOLDER DISCLAIMS ANY LIABILITY OF ANY KIND FOR ANY 
 *  DAMAGES WHATSOEVER RESULTING DIRECTLY OR INDIRECTLY FROM THE USE OF THIS SOFTWARE 
 *  OR OF ANY DERIVATIVE WORK.
 *
 *  Coded by Nat!
 *
 *  $Id: NSData+MulleCipherDigests.m,v 1.1.1.1 2001/02/22 14:55:32 znek Exp $
 *
 *  $Log: NSData+MulleCipherDigests.m,v $
 *  Revision 1.1.1.1  2001/02/22 14:55:32  znek
 *  Re-import of Nat!'s cryptographic framework. This version has been
 *  ported to MOSX, MOSXS and Solaris. It uses an extended build process
 *  similar to EDCommon & friends.
 *
 *  Revision 1.1.1.1  1970/01/01 22:37:33  nat
 *  Mercyful Release
 *
 */

#import "NSData+MulleCipherDigests.h"
#include "md5.h"
#include "sha1.h"

unsigned long crc32( const unsigned char *s, unsigned int len);


@implementation NSData ( MulleCipherDigests)

- (NSData *) md5Digest
{
    isc_md5_t       context;
    unsigned char   digest[ ISC_MD5_DIGESTLENGTH];
    
    isc_md5_init( &context);
    isc_md5_update( &context, (const unsigned char *) [self bytes], [self length]);
    isc_md5_final( &context, digest);

    return( [NSData dataWithBytes:digest
                           length:ISC_MD5_DIGESTLENGTH]);
}


+ (NSData *) md5DigestForDatas:(NSArray *) array
{
    isc_md5_t       context;
    unsigned char   digest[ ISC_MD5_DIGESTLENGTH];
    unsigned int    i, n;
    NSData          *p;
    
    n = [array count];
    isc_md5_init( &context);
    for( i = 0; i < n; i++)
    {
        p = [array objectAtIndex:i];
        isc_md5_update( &context, (const unsigned char *) [p bytes], [p length]);
    }
    isc_md5_final( &context, digest);

    return( [NSData dataWithBytes:digest
                           length:ISC_MD5_DIGESTLENGTH]);
    
}


- (NSData *) sha1Digest
{
    isc_sha1_t      context;
    unsigned char   digest[ ISC_SHA1_DIGESTLENGTH];
    
    isc_sha1_init( &context);
    isc_sha1_update( &context, (const unsigned char *) [self bytes], [self length]);
    isc_sha1_final( &context, digest);

    return( [NSData dataWithBytes:digest
                           length:ISC_SHA1_DIGESTLENGTH]);
}


+ (NSData *) sha1DigestForDatas:(NSArray *) array
{
    isc_sha1_t      context;
    unsigned char   digest[ ISC_SHA1_DIGESTLENGTH];
    unsigned int    i, n;
    NSData          *p;

    n = [array count];
    isc_sha1_init( &context);
    for( i = 0; i < n; i++)
    {
        p = [array objectAtIndex:i];
        isc_sha1_update( &context, (const unsigned char *) [p bytes], [p length]);
    }
    isc_sha1_final( &context, digest);

    return( [NSData dataWithBytes:digest
                           length:ISC_SHA1_DIGESTLENGTH]);

}


- (unsigned long) crc32
{
    return( crc32( [self bytes], [self length]));
}

@end
