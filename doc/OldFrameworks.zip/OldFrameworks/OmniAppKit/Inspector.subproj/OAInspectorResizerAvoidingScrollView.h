// Copyright 2003 Omni Development, Inc.  All rights reserved.
//
// This software may only be used and reproduced according to the
// terms in the file OmniSourceLicense.html, which should be
// distributed with this project and can also be found at
// http://www.omnigroup.com/DeveloperResources/OmniSourceLicense.html.
//
// $Header: /Network/Source/CVS/OmniGroup/Frameworks/OmniAppKit/Inspector.subproj/OAInspectorResizerAvoidingScrollView.h,v 1.1 2003/03/26 09:54:35 wjs Exp $

#import <AppKit/NSScrollView.h>

@interface OAInspectorResizerAvoidingScrollView : NSScrollView
{
}

// API

@end
