// Copyright 1997-2003 Omni Development, Inc.  All rights reserved.
//
// This software may only be used and reproduced according to the
// terms in the file OmniSourceLicense.html, which should be
// distributed with this project and can also be found at
// http://www.omnigroup.com/DeveloperResources/OmniSourceLicense.html.

#import "NSTableView-OAColumnConfigurationExtensions.h"

#import <Foundation/Foundation.h>
#import <AppKit/AppKit.h>
#import <OmniBase/OmniBase.h>
#import <OmniFoundation/OmniFoundation.h>


RCS_ID("$Header: /Network/Source/CVS/OmniGroup/Frameworks/OmniAppKit/OpenStepExtensions.subproj/NSTableView-OAColumnConfigurationExtensions.m,v 1.2 2003/05/08 03:57:08 rick Exp $")

@interface NSTableView (OAColumnConfigurationPrivate)
- (void)_setupColumnsAndMenu;
- (void)_addItemWithTableColumn:(NSTableColumn *)column toMenu:(NSMenu *)menu;
- (NSMenuItem *)_menuItemForTableColumn:(NSTableColumn *)column;
- (void)_toggleColumn:(id)sender;
@end

@interface NSTableView (OAColumnConfigurationDelegateDataSourceCoverMethods)
- (BOOL)_columnConfigurationEnabled;
- (NSArray *)_defaultColumnIdentifiers;
- (NSString *)_menuStringForColumn:(NSTableColumn *)column;
- (BOOL)_shouldAllowTogglingColumn:(NSTableColumn *)column;
- (BOOL)_shouldAddMenuSeparatorAfterColumn:(NSTableColumn *)column;
- (void)_willActivateColumn:(NSTableColumn *)column;
- (void)_didActivateColumn:(NSTableColumn *)column;
- (void)_willDeactivateColumn:(NSTableColumn *)column;
- (void)_didDeactivateColumn:(NSTableColumn *)column;
@end


// TODO: override -addTableColumn: and -removeTableColumn: to update the menu. 

@implementation NSTableView (OAColumnConfigurationExtensions)

static IMP originalSetDataSource;
static IMP originalReloadData;
static IMP originalTableColumnWithIdentifier;

+ (void)didLoad;
{
    originalSetDataSource = OBReplaceMethodImplementationWithSelector(self, @selector(setDataSource:), @selector(_replacementSetDataSource:));
    originalReloadData = OBReplaceMethodImplementationWithSelector(self, @selector(reloadData), @selector(_replacementReloadData));
    originalTableColumnWithIdentifier = OBReplaceMethodImplementationWithSelector(self, @selector(tableColumnWithIdentifier:), @selector(_replacementTableColumnWithIdentifier:));
}


// NSTableView method replacements

- (void)_replacementSetDataSource:(id)dataSource;
{
    originalSetDataSource(self, _cmd, dataSource);
    [self _setupColumnsAndMenu];
}

- (void)_replacementReloadData;
{
    NSArray *menuItems;
    unsigned int itemIndex;

    originalReloadData(self, _cmd);

    if (![self _columnConfigurationEnabled])
        return;
    
    menuItems = [[self columnsMenu] itemArray];
    for (itemIndex = 0; itemIndex < [menuItems count]; itemIndex++) {
        NSMenuItem *item;
        NSTableColumn *column;

        item = [menuItems objectAtIndex:itemIndex];
        column = [item representedObject];
        [[self _menuItemForTableColumn:column] setState:[self isTableColumnActive:column]];
    }
}

- (NSTableColumn *)_replacementTableColumnWithIdentifier:(id)identifier;
{
    // We want this method to search both active and inactive columns (OOM depends upon this).  Neither the configuration menu nor the tableColumns array is guaranteed to have all the items (the configuration menu will have all but those that cannot be configured and the tableColumns will have only the active columns).  This is one place where our strategy of not adding an ivar for 'all table columns' is wearing thin.
    
    NSArray        *items;
    unsigned int    itemIndex;
    NSMenuItem     *item;
    NSTableColumn  *column;

    if (![self _columnConfigurationEnabled])
        return originalTableColumnWithIdentifier(self, _cmd, identifier);
                
    // First check the configuration menu
    items = [[self columnsMenu] itemArray];
    itemIndex = [items count];
    while (itemIndex--) {
        item = [items objectAtIndex:itemIndex];
        column = [item representedObject];

        if ([[column identifier] isEqual:identifier])
            return column;
    }

    // Then check the table view (since it might have unconfigurable columns)
    items = [self tableColumns];
    itemIndex = [items count];
    while (itemIndex--) {
        column = [items objectAtIndex:itemIndex];
        if ([[column identifier] isEqual:identifier])
            return column;
    }
    
    return nil;
}


// New API

- (NSMenu *) columnsMenu;
{
    OBPRECONDITION([self _columnConfigurationEnabled]);
    
    return [[self headerView] menu];
}

- (NSArray *)inactiveTableColumns;
{
    NSMutableArray *inactiveTableColumns;
    NSArray        *items;
    unsigned int    itemIndex;
    NSMenuItem     *item;
    NSTableColumn  *column;

    OBPRECONDITION([self _columnConfigurationEnabled]);
    
    inactiveTableColumns = [NSMutableArray array];
    items = [[self columnsMenu] itemArray];
    itemIndex = [items count];
    while (itemIndex--) {
        item = [items objectAtIndex:itemIndex];
        column = [item representedObject];

        if (![self isTableColumnActive:column])
            [inactiveTableColumns addObject:column];
    }

    return inactiveTableColumns;
}

- (void)activateTableColumn:(NSTableColumn *)column;
{
    NSMenuItem *item;

    OBPRECONDITION([self _columnConfigurationEnabled]);
    
    if ([[self tableColumns] indexOfObjectIdenticalTo:column] != NSNotFound)
        return; // Already active

    [self _willActivateColumn:column];
        
    item = [self _menuItemForTableColumn:column];
    [item setState:YES];
    
    [self addTableColumn:column];

    [self _didActivateColumn:column];
}

- (void)deactivateTableColumn:(NSTableColumn *)column;
{
    NSMenuItem *item;

    OBPRECONDITION([self _columnConfigurationEnabled]);
    
    if ([[self tableColumns] indexOfObjectIdenticalTo:column] == NSNotFound)
        return; // Already inactive

    [self _willDeactivateColumn:column];
        
    item = [self _menuItemForTableColumn:column];
    [item setState:NO];
    
    [self removeTableColumn:column];

    [self _didDeactivateColumn:column];
}

- (void)toggleTableColumn:(NSTableColumn *)column;
{
    OBPRECONDITION([self _columnConfigurationEnabled]);
    OBPRECONDITION(column);
    OBPRECONDITION([self _menuItemForTableColumn:column]);
    
    if ([self isTableColumnActive:column])
        [self deactivateTableColumn:column];
    else
        [self activateTableColumn:column];
    
    [self tile];
    if ([self autoresizesAllColumnsToFit]) {
        [self sizeToFit];
    }
}

- (BOOL)isTableColumnActive:(NSTableColumn *)column;
{
    OBPRECONDITION([self _columnConfigurationEnabled]);
    
    return [[self tableColumns] indexOfObject:column] != NSNotFound;
}

@end


@implementation NSTableView (OAColumnConfigurationPrivate)

- (void)_setupColumnsAndMenu;
{
    NSMenu *columnsMenu;
    NSEnumerator  *tableColumnEnum;
    NSTableColumn *tableColumn;
    NSArray *defaultColumnIdentifiers;
    
    if (_dataSource == nil || ![self _columnConfigurationEnabled])
        return;

    columnsMenu = [[NSMenu alloc] initWithTitle:@"Configure Columns"];
        
    // Add menu items for all the columns.  For columns that aren't currently displayed, this will be where we store the pointer to the column.
    // Also deactivate any columns that aren't supposed to show up in the default configuration.
    tableColumnEnum = [[self tableColumns] objectEnumerator];
    defaultColumnIdentifiers = [self _defaultColumnIdentifiers];
    while ((tableColumn = [tableColumnEnum nextObject])) {
        [self _addItemWithTableColumn:tableColumn toMenu:columnsMenu];
        if (![defaultColumnIdentifiers containsObject:[tableColumn identifier]])
            [self deactivateTableColumn:tableColumn];
    }

    [[self headerView] setMenu:columnsMenu];
    [columnsMenu release];
}

- (void)_addItemWithTableColumn:(NSTableColumn *)column toMenu:(NSMenu *)menu;
{
    NSMenuItem *item;
    NSString *title = nil;
    
    // If we don't allow configuration, don't add the item to the menu
    if (![self _shouldAllowTogglingColumn:column])
        return;
    
    title = [self _menuStringForColumn:column];
    item = [[NSMenuItem alloc] initWithTitle:title action:@selector(_toggleColumn:) keyEquivalent:@""];
    [item setState:[self isTableColumnActive:column]];
    [item setRepresentedObject:column];
    [menu addItem:item];
    [item release];
    
    if ([self _shouldAddMenuSeparatorAfterColumn:column])
        [menu addItem:[NSMenuItem separatorItem]];
}

- (NSMenuItem *)_menuItemForTableColumn:(NSTableColumn *) column;
{
    NSArray        *items;
    unsigned int    itemIndex;
    NSMenuItem     *item;
    
    items = [[self columnsMenu] itemArray];
    itemIndex = [items count];
    while (itemIndex--) {
        item = [items objectAtIndex:itemIndex];
        if (column == [item representedObject])
            return item;
    }

    return nil;
}

- (void)_toggleColumn:(id)sender;
{
    NSMenuItem *item;
    
    item = (NSMenuItem *)sender;
    OBASSERT([item isKindOfClass:[NSMenuItem class]]);

    [self toggleTableColumn:[item representedObject]];
}

@end

@implementation NSTableView (OAColumnConfigurationDelegateDataSourceCoverMethods)

- (BOOL)_columnConfigurationEnabled;
{
    return [_dataSource respondsToSelector:@selector(tableViewDefaultColumnIdentifiers:)];
}

- (NSArray *)_defaultColumnIdentifiers;
{
    if ([_dataSource respondsToSelector:@selector(tableViewDefaultColumnIdentifiers:)]) {
        NSArray *identifiers;

        identifiers = [_dataSource tableViewDefaultColumnIdentifiers:self];
        if ([identifiers count] < 1)
            [NSException raise:NSInvalidArgumentException format:@"-tableViewDefaultColumnIdentifiers: must return at least one valid column identifier"];
        else
            return identifiers;
    } else {
        return [[self tableColumns] arrayByPerformingSelector:@selector(identifier)];
    }

    return nil; // not reached but it makes the compiler happy
}

- (NSString *)_menuStringForColumn:(NSTableColumn *)column;
{
    if ([_dataSource respondsToSelector:@selector(tableView:menuStringForColumn:)])
        return [_dataSource tableView:self menuStringForColumn:column];
    else
        return [[column headerCell] stringValue];
}

- (BOOL)_shouldAllowTogglingColumn:(NSTableColumn *)column;
{
    if ([_dataSource respondsToSelector:@selector(tableView:shouldAllowTogglingColumn:)])
        return [_dataSource tableView:self shouldAllowTogglingColumn:column];
    else
        return YES;
}

- (BOOL)_shouldAddMenuSeparatorAfterColumn:(NSTableColumn *)column;
{
    if ([_dataSource respondsToSelector:@selector(tableView:shouldAddMenuSeparatorAfterColumn:)])
        return [_dataSource tableView:self shouldAddMenuSeparatorAfterColumn:column];
    else
        return NO;
}

- (void)_willActivateColumn:(NSTableColumn *)column;
{
    if ([_dataSource respondsToSelector:@selector(tableView:willActivateColumn:)])
        [_dataSource tableView:self willActivateColumn:column];
}

- (void)_didActivateColumn:(NSTableColumn *)column;
{
    if ([_dataSource respondsToSelector:@selector(tableView:didActivateColumn:)])
        [_dataSource tableView:self didActivateColumn:column];
}

- (void)_willDeactivateColumn:(NSTableColumn *)column;
{
    if ([_dataSource respondsToSelector:@selector(tableView:willDeactivateColumn:)])
        [_dataSource tableView:self willDeactivateColumn:column];
}

- (void)_didDeactivateColumn:(NSTableColumn *)column;
{
    if ([_dataSource respondsToSelector:@selector(tableView:didDeactivateColumn:)])
        [_dataSource tableView:self didDeactivateColumn:column];
}

@end
